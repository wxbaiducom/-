var newURL="woolk.nm9e.cn";
var heziURL="tzdsl.p0z46b.cn";
